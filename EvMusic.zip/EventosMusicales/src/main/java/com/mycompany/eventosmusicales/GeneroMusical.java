package com.mycompany.eventosmusicales;


public enum GeneroMusical {
    ROCK, 
    JAZZ, 
    POP, 
    CLASICA,
    ELECTRONICA;
}
