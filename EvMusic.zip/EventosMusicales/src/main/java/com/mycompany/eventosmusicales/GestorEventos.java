package com.mycompany.eventosmusicales;


import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.function.Function;
import java.util.function.Predicate;


public class GestorEventos<T extends CSVSerializable> implements Gestionable<T>{
    List<T> lista = new ArrayList<>();

    @Override
    public void agregar(T item) {
        if(item == null){
            throw new IllegalArgumentException("ERROR, me estas pasando un nulo");
        }
        lista.add(item);
    }

    @Override
    public T obtener(int indice) {
        verificarLista();
        verificarIndice(indice);
        return lista.get(indice);
    }

    @Override
    public void eliminar(int indice) {
        verificarLista();
        verificarIndice(indice);
        lista.remove(indice);
    }

    @Override
    public List<T> filtrar(Predicate<T> predicado) {
        verificarLista();
        List<T> aux = new ArrayList<>();
        for (T item : lista){
            if(predicado.test(item)){
                aux.add(item);
            }
        }
        return aux;
    }

    @Override
    public void ordenar() {
        ordenar((Comparator<T>) Comparator.naturalOrder());
    
    }

    @Override
    public void ordenar(Comparator<T> comparador) {
        verificarLista();
        lista.sort(comparador);
    }
    
    private void verificarLista(){
        if (lista.isEmpty()){
            throw new IndexOutOfBoundsException("La lista esta vacia");
        }
    }
    
    private void verificarIndice(int indice){
        if (lista.size() < indice || indice < 0){
            throw new IndexOutOfBoundsException("El indice no corresponde con la lista");
        }
    }

    
    @Override
    public void guardarEnBinario(String path) throws IOException{
        try (ObjectOutputStream salida = new ObjectOutputStream(new FileOutputStream(path))){
            salida.writeObject(lista);
            
        } catch (IOException ex){
            System.out.println(ex.getMessage());
        }
        mostrarTodos();
    }

    
    @Override
    public void cargarDesdeBinario(String path) throws IOException, ClassNotFoundException{
        try (ObjectInputStream input = new ObjectInputStream(new FileInputStream(path))){
            lista = (List<T>) input.readObject();
        }
    }

    @Override
    public void guardarEnCSV(String path) throws IOException{
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(path))){
            bw.write("id,nombre,especie,alimentacion\n");
            for(T item : lista){
                bw.write(item.toCSV() + "\n");
            }
        }
    }
    
    @Override
    public void cargarDesdeCSV(String path, Function<String, T> funcion) throws IOException{
        lista.clear(); 
        try (BufferedReader bf = new BufferedReader(new FileReader(path))) { 
        String linea;
        bf.readLine(); 
        while ((linea = bf.readLine()) != null) { 
            lista.add(funcion.apply(linea)); 
            }
        }
    }

    @Override
    public void mostrarTodos() {
        for(T item : lista){
            System.out.println(item);
        }
    }
    
    
}
