package com.mycompany.eventosmusicales;

public class AppConfig {
    public static final String PATH_SER = "src/main/java/resources/evento.ser";
    public static final String PATH_CSV = "src/main/java/resources/eventoCSV.csv";
    
    
}
