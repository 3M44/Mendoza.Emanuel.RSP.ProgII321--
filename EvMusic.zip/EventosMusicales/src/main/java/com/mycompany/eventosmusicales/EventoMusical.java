package com.mycompany.eventosmusicales;

import java.io.Serializable;
import java.time.LocalDate;


public class EventoMusical extends Evento implements CSVSerializable, Serializable, Comparable<EventoMusical>{
    private static final long SerialVersionUID = 1l;
    private String artista;
    private GeneroMusical genero;

    public EventoMusical(int id, String nombre, LocalDate fecha, String artista, GeneroMusical genero) {
        super(id, nombre, fecha);
        this.artista = artista;
        this.genero = genero;
    }

    @Override
    public String toString() {
        return "EventoMusical{" + "artista=" + artista + ", genero=" + genero + ',' + super.toString();
    }

    public GeneroMusical getGenero() {
        return genero;
    }
    
    @Override
    public String toCSV(){
        return super.getId() + "," + artista + "," + super.getFecha() + "," + super.getNombre() + "," + genero ;
    }
    
    public static EventoMusical fromCSV(String eventoCSV){
        
        String[] valores = eventoCSV.split(",");
        
        return new EventoMusical(Integer.parseInt(valores[0]),
        valores[1],
        LocalDate.parse(valores[2]),    
        valores[3],
        GeneroMusical.valueOf(valores[4]));
    }

    @Override
    public int compareTo(EventoMusical o) {
        return Integer.compare(super.getId(), o.getId());
    }
}
