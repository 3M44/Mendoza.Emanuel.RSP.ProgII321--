package com.mycompany.eventosmusicales;

public interface CSVSerializable {
    String toCSV();
}
